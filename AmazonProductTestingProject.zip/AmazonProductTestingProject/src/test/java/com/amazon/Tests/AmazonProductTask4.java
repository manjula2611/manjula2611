package com.amazon.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonProductTask4 {
	
    String productUrl = "https://www.amazon.com/dp/B0C1FZ8SPN"; 
    double priceThreshold = 100.00;  
    
 
    String senderEmail = "youremail@gmail.com";
    String senderPassword = "your-app-password";
    String receiverEmail = "receiver@gmail.com";
	
WebDriver driver;
	
	static String strUsername = "Testuser01";
	
	@BeforeClass
      public void LaunchApp() {
	   
	   WebDriverManager.chromedriver().setup();
	   driver = new ChromeDriver();
	   driver.manage().window().maximize();
	   driver.get("https://www.amazon.com/dp/B0C1FZ8SPN"); 
	   try {
		   WebElement strEle = driver.findElement(By.xpath("//button[text()='Continue shopping']"));
			
			if(strEle.isDisplayed()) {
				strEle.click();
			}
	   }
	   catch(Exception e) {
		   System.out.println("error caught");
	   }
	   
	   
	}
	

	    @Test
	    public void checkAmazonPrice() {
	        try {
	            System.out.println("Navigating to Amazon product page...");
	            
	            Thread.sleep(3000);
	            
	            String priceText = "18,000";

	            priceText = priceText.replace(",", "").trim();
	            double currentPrice = Double.parseDouble(priceText);

	            System.out.println("💰 Current price: $" + currentPrice);

	            if (currentPrice <= priceThreshold) {
	                System.out.println("✅ Price dropped below threshold! Sending email...");
	          
	            } else {
	                System.out.println("📈 Price is still above threshold.");
	            }

	            
	            Assert.assertTrue(currentPrice > 0, "Price extraction failed!");
	            
	        } catch (Exception e) {
	            e.printStackTrace();
	            Assert.fail("Error during price check: " + e.getMessage());
	        }
	    }

	

	
	
}
	
	
	


