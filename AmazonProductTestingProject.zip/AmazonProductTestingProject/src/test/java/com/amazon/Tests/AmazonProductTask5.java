package com.amazon.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonProductTask5 {

	 WebDriver driver;
     
		@BeforeClass
	      public void LaunchApp() {
		   
		   WebDriverManager.chromedriver().setup();
		   driver = new ChromeDriver();
		   driver.manage().window().maximize();
		   driver.get("https://www.amazon.in/"); 
		   
		   try {
			   WebElement strEle = driver.findElement(By.xpath("//button[text()='Continue shopping']"));
				
				if(strEle.isDisplayed()) {
					strEle.click();
				}
		   }
		   catch(Exception e) {
			   System.out.println("error caught");
		   }
		}
		
	@Test(priority=0)
	public void SearchingProduct() {
      driver.findElement(By.xpath("//input[@id=\"twotabsearchtextbox\"]")).sendKeys("Mobiles",Keys.ENTER);
      JavascriptExecutor js = (JavascriptExecutor)driver;

		WebElement fb = driver.findElement(By.xpath("//span[text()='Apple iPhone 15 (128 GB) - Green']"));

		js.executeScript("arguments[0].scrollIntoView()", fb);
      driver.findElement(By.xpath("//span[text()='Apple iPhone 15 (128 GB) - Green']/following::button[text()='Add to cart'][1]")).click();
      driver.findElement(By.xpath("//span[@id=\"nav-cart-count\"]")).click();
	}
      @Test(priority=1)
      public void SubTotal() {
      WebElement subtotalElement =driver.findElement(By.xpath("//span[@id='sc-subtotal-label-activecart']"));
	  String subtotalText = subtotalElement.getText();
      System.out.println("Subtotal Name: " + subtotalText);
      }
      
      @Test(priority=2)
      public void ProceedToCheck() throws InterruptedException {
    	  driver.findElement(By.xpath("//input[@name=\"proceedToRetailCheckout\"]")).click();
    	  
    	  
      
}
}