package com.amazon.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonProductTask6 {
	
	WebDriver driver;
	
	@BeforeClass
    public void LaunchApp() {
	   
	   WebDriverManager.chromedriver().setup();
	   driver = new ChromeDriver();
	   driver.manage().window().maximize();
	   driver.get("https://www.amazon.in/"); 
	   
	   try {
		   WebElement strEle = driver.findElement(By.xpath("//button[text()='Continue shopping']"));
			
			if(strEle.isDisplayed()) {
				strEle.click();
			}
	   }
	   catch(Exception e) {
		   System.out.println("error caught");
	   }
	}
	
	@Test
	public void ProcessOfSearchingProduct() throws Exception {
		
		driver.findElement(By.xpath("//input[@id=\"twotabsearchtextbox\"]")).sendKeys("fancy sarees for women latest design",Keys.ENTER);
		
		
		 driver.findElement(By.xpath("//span[text()='Brands']/following::span[text()='See more'][1]")).click();
		 driver.findElement(By.xpath("//span[text()='C J Enterprise']")).click();
		 driver.findElement(By.xpath("//span[text()='Ready Pleated Saree']")).click();
		 driver.findElement(By.xpath("//span[text()='Solid']")).click();
		 driver.findElement(By.xpath("//span[text()='Banarasi']")).click();

	}
}




