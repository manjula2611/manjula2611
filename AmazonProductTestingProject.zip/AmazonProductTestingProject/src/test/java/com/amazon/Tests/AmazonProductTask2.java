package com.amazon.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
//import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonProductTask2 {
    
	WebDriver driver;
	
	static String strUsername = "Testuser01";
	
	@BeforeClass
      public void LaunchApp() {
	   
	   WebDriverManager.chromedriver().setup();
	   driver = new ChromeDriver();
	   driver.manage().window().maximize();
	   driver.get("https://www.amazon.in/"); 
	   try {
		   WebElement strEle = driver.findElement(By.xpath("//button[text()='Continue shopping']"));
			
			if(strEle.isDisplayed()) {
				strEle.click();
			}
	   }
	   catch(Exception e) {
		   System.out.println("error caught");
	   }
	   
	   
	}
	  
  @Test(priority=0)
  public void SearchTheProduct() throws InterruptedException {
	  driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("lipstick for women",Keys.ENTER);
	  Thread.sleep(5000);
	  driver.findElement(By.xpath("//span[text()='Over ₹450']")).click();
	  
	
  }
  
  @Test(priority=1)
  public void MultipleProduct() {
	   driver.findElement(By.xpath("//button[@id='a-autoid-74-announce']")).click();
	   driver.findElement(By.xpath("//button[@id='a-autoid-76-announce']")).click();
	   driver.findElement(By.xpath("//button[@id='a-autoid-77-announce']")).click();
	   driver.findElement(By.xpath("//button[@id='a-autoid-78-announce']")).click();
	   driver.findElement(By.xpath("//button[@id='a-autoid-79-announce']")).click();
        }
  @Test(priority = 2)
  public void CartIcon() {
	  driver.findElement(By.xpath("//span[@class='nav-cart-count nav-progressive-attribute nav-progressive-content nav-cart-1']")).click();
	  WebElement subtotalElement =driver.findElement(By.xpath("//span[@id='sc-subtotal-label-buybox']"));
	  
	  String subtotalText = subtotalElement.getText();
      System.out.println("Subtotal Name: " + subtotalText);


  }
  
  @Test(priority = 3)
  public void stringlength() {
	  int strLength = strUsername.length();
	  System.out.println("Length of the username is :" +strLength);
	  
  }
  
  @Test(priority = 4)

public void containsSpecialCharacter() {

	  boolean str1 = !strUsername.matches("[A-Za-z0-9 ]*");
	  System.out.println(str1);
}
  
}
	  
  
  
  