package com.amazon.Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonProductTask1 {
	
	WebDriver driver;
	
	
	
	@BeforeClass
	 public void LaunchApp() {
	
    WebDriverManager.chromedriver().setup();
	
	driver = new ChromeDriver();
	
	driver.get("https://www.amazon.com/");
	driver.manage().window().maximize();
	
	WebElement strEle = driver.findElement(By.xpath("//button[text()='Continue shopping']"));
	
	if(strEle.isDisplayed()) {
		strEle.click();
	}
	
	}
	
	@Test
	public void SelectedProductSearchResult() throws Exception {
	
	String str = "Sweaters for women";

	char ch = str.charAt(0);
	
	System.out.println(ch);
	
	if (ch=='A' | ch=='B' | ch=='C' | ch=='D') {
		
		System.out.println("Ignore");
	}
	else {
		System.out.println("String is not starting from A B C D");
		Thread.sleep(3000);
		 driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).click();
		 driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(str);
		
			
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).submit();
		 
		driver.findElement(By.xpath("//span[text()=\"Trendy Queen Women's Oversized Cable Knit Crewneck Sweaters\"]")).click();
		
		
		JavascriptExecutor js = (JavascriptExecutor)driver;

		WebElement fb = driver.findElement(By.xpath("//h3[text()=' Product details ']"));

		js.executeScript("arguments[0].scrollIntoView()", fb);
		
		String fabricType = driver.findElement(By.xpath("//span[text()='Fabric type']//following::span[2]")).getText();
		System.out.println(fabricType);
		
		String careInstructions = driver.findElement(By.xpath("//span[text()='Care instructions']//following::span[2]")).getText();
		System.out.println(careInstructions);
		
		String origin = driver.findElement(By.xpath("//span[text()='Origin']//following::span[2]")).getText();
		System.out.println(origin);
		
		
		String closureType = driver.findElement(By.xpath("//span[text()='Closure type']//following::span[2]")).getText();
		System.out.println(closureType);
	}
	

}

}



